<template>
    <div class="col-xs-12 col-sm-6">
        <p>Server Details are currently not updated</p>
    </div>

</template>

<script>
</script>

<style>

</style>
